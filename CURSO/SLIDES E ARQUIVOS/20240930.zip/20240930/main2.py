#coding:utf-8 

nome= "Mirella"
Altura = 1.70
NumeroSapato = 38

nome2= "Augustinho"
Altura2=1.87
NumeroSapato2 = 45

print("Entre com o nome: ", end = '')
nome3 = input()
print("Entre com a altura:", end = ' ')
Altura3 = float(input())
NumeroSapato3 = int(input("Entre com o numero do sapato: "))

'''
print(type(nome))
print(type(Altura))
print(type(NumeroSapato))
'''

print(nome+nome3)
print(Altura+Altura3)
print(NumeroSapato+NumeroSapato3)


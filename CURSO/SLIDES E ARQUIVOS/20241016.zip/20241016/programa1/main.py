#coding: utf-8
import FuncoesEntrada as FE
import MetodosVetores as MV

if __name__ == "__main__": 
	MV.Insercao_dado()
	#FE.forma1_leitura()
	#FE.forma2_leitura()
	#FE.forma3_leitura_array()
	

#coding: utf-8
def map1():
	def aprovar_pessoa(nome):
		return nome+" APROVADO"
	nomes = ['Larissa', 'Rafael', 'Marcos','Joao']	
	print(nomes)
	'''
	for i in range(len(nomes)):
		nomes[i] = aprovar_pessoa(nomes[i])
	print(nomes)	
	'''
	situacao = list(map(aprovar_pessoa, nomes))
	nomes = list(map(aprovar_pessoa, nomes))
	print(situacao)
	print(nomes)

def map2(): 
	print('Entre com uma quantidade de numeros: ')
	A = input().split()
	A = list(map(float, A))
	print(A)
	#print(B)

def Filter1():
	pinturas = [
		['Picasso', 'Les demoiselles', 1907],
		['Monet', "Lagoa dos lirios d’água", 1899],
		['Renoir', 'Duas irmãs', 1881] ,
		['Tarcila', 'Abaporu', 1928] ]
	def antiguidade(pintura):
		if pintura[2]<1900:
			return True
		else:
			return False
	print("Filter")
	Pinturas_Filter = list(filter(antiguidade, pinturas))
	print(Pinturas_Filter)
	print("Aplicação de Map")	
	print(list(map(antiguidade, pinturas)))		
	
def set1(): 
	numeros = [2,2,5,8]
	set_numeros = (set(numeros))
	set_numeros= sorted(set_numeros)
	print(set_numeros)
	frutas = ['maca', 'uva', 'banana', 'maca', 'morango']
	print(frutas)
	frutas2 = {'maca', 'uva', 'banana', 'maca', 'morango'}
	print(frutas2)
		
	
if __name__=="__main__": 
	set1()
	#Filter1()
	#map2()
	#map1()	

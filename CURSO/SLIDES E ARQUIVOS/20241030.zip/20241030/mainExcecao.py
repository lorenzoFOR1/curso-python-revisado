#coding: utf-8

nomes = ['Larissa', 'Rafael', 'Marcos','Joao']
#for i in range(5): #
#	print(nomes[i])


try: 
	for i in range(4): 
		print(nomes[i])
except IndexError as erro1: 
	print("Houve um erro de indice") 
	print(erro1) 
else: 	
	print("Programa nao passou com erro.")	
print("L7")	


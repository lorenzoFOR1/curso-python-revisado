#coding: utf-8
import time 

def MedeTempo(func):
	def envelope(*args):
		tempo_inicial = time.perf_counter()
		resultado = func(*args)
		tempo_final = time.perf_counter()
		DeltaTempo = tempo_final-tempo_inicial
		strg = "Tempo gasto por {0}: {1:.5f}".format(func.__name__, DeltaTempo)
		print(strg)
		return resultado
	return envelope

#@MedeTempo
def tempo_laco():
	for _ in range(int(1e06)):
		pass
	print("Acabou o laço") 			

import math as m
@MedeTempo
def Equacao2grau(a,b,c):
	Coeficiente_a = a
	Coeficiente_b = b
	Coeficiente_c = c
	Delta = m.pow(Coeficiente_b,2)-4*Coeficiente_a*Coeficiente_c
	x1 = (-Coeficiente_b-m.pow(Delta, 0.5))/(2*Coeficiente_a)
	x2 = (-Coeficiente_b+m.pow(Delta, 0.5))/(2*Coeficiente_a)
	print("Primeira solução: ", x1)
	print("Segunda solução: ", x2)


		
#tempo_laco()

Equacao2grau(1,5,4)

#resultado = MedeTempo(tempo_laco)
#resultado()		

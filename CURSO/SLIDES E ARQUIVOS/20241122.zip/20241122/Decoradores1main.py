#coding: utf-8
def antes():
	print("Antes da função")
def depois():
	print("Depois da função")
def parabenizar():
	print("Parabens")
	
def meu_decorador(funcao): #Envia a referencia da função
	def envelope():
		antes()
		funcao() 
		#Agora não é referencia, executa a função
		depois()
	return envelope	

import math as m
def Equacao2grau():	
	Coeficiente_a = 1
	Coeficiente_b = 5
	Coeficiente_c = 4
	Delta = m.pow(Coeficiente_b,2)-4*Coeficiente_a*Coeficiente_c

	x1 = (-Coeficiente_b-m.pow(Delta, 0.5))/(2*Coeficiente_a)
	x2 = (-Coeficiente_b+m.pow(Delta, 0.5))/(2*Coeficiente_a)
	print("Primeira solução: ", x1)
	print("Segunda solução: ", x2)

	
resultado=meu_decorador(parabenizar)
#resultado é o endereco de uma função que tem os comando do envelope
resultado()	

resultado2=meu_decorador(Equacao2grau)
resultado2()

#coding: utf-8

def conta_aluno(nome, peso, *args,**kwargs):
	print("Nome: {0}, peso = {1}".format(nome, peso))
	print("args: ", args)
	print("kwargs: ", kwargs)
	for arg in args:
		print(arg)
	for kwarg in kwargs.items():
		print(kwarg)

def pai(numero):
	def filho_1():
		print("Chamou filho 1")

	def filho_2():
		print("Chamou filho 2")

	if numero==1:
		return filho_1
	else:
		return filho_2

		
#Drivers:
if __name__=="__main__":
	#Problema 2
	resultado = pai(1)
	resultado()	
	#Problema 1
	#conta_aluno("Marcio", "80kg",5,3,2,a=1, b=2, c=9)
	#print()
	#conta_aluno("80kg",5,3,2,a=1, b=2, c=9)

texto = "    banana     "
print("De todas as frutas, ", texto, " é minha favorita." )
x = texto.strip() #Remove os espaços
print("De todas as frutas, ", x, " é minha favorita." )
texto2 = ",,,,a,rrttgg.. ...goiaba.. ..rrur"
print(texto2)
x2 = texto2.strip(",. grt") #Remove espaço e os 5 caracteres.
print("Eu não gosto de ",x2)
